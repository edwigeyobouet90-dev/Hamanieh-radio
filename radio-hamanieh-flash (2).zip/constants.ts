
export const RADIO_NAME = "hamanieh-flash.net";
export const STREAM_URL = "http://ecmanager5.pro-fhi.net:2870/;?type=http&nocache=1769072904";
export const PHONE_NUMBER = "+2250757443661";
export const WHATSAPP_LINK = "https://wa.me/2250757443661";
export const EMAIL_CONTACT = "hamaniehflashnet@gmail.com";
export const FACEBOOK_LINK = "https://www.facebook.com/hamaniehflash";
export const TIKTOK_LINK = "https://www.tiktok.com/@hamaniehflashnet?_r=1&_t=ZS-93SBAJJdF5B";

export const COLORS = {
  NAVY: "#0a0e1a",
  GOLD: "#D4AF37",
  GOLD_MUTED: "rgba(212, 175, 55, 0.6)",
};
