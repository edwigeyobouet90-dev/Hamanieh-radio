
import React from 'react';
import { NavItem } from '../types';
import { 
  FACEBOOK_LINK, 
  TIKTOK_LINK, 
  PHONE_NUMBER, 
  WHATSAPP_LINK, 
  COLORS 
} from '../constants';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, onNavigate }) => {
  const menuItems: NavItem[] = [
    { id: 'home', label: 'Accueil', icon: 'fa-house', action: () => onNavigate('home') },
    { id: 'whatsapp', label: 'Écrivez-nous', icon: 'fa-brands fa-whatsapp', link: WHATSAPP_LINK, isExternal: true },
    { id: 'call', label: 'Appelez-nous', icon: 'fa-phone', link: `tel:${PHONE_NUMBER}`, isExternal: true },
    { id: 'facebook', label: 'Facebook', icon: 'fa-brands fa-facebook', link: FACEBOOK_LINK, isExternal: true },
    { id: 'tiktok', label: 'Tik Tok', icon: 'fa-brands fa-tiktok', link: TIKTOK_LINK, isExternal: true },
    { id: 'about', label: 'À propos', icon: 'fa-circle-info', action: () => onNavigate('about') },
  ];

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Sidebar Content */}
      <div 
        className={`fixed top-0 left-0 h-full w-72 bg-navy border-r border-gold/30 z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-6 border-b border-gold/20 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gold rounded-full flex items-center justify-center">
              <i className="fa-solid fa-radio text-navy text-xl"></i>
            </div>
            <span className="font-bold text-gold tracking-tight">Hamanieh Flash</span>
          </div>
          <button onClick={onClose} className="text-gold text-2xl hover:scale-110 transition-transform">
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        <nav className="mt-6 px-4 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                if (item.isExternal && item.link) {
                  window.open(item.link, '_blank');
                } else if (item.action) {
                  item.action();
                }
                onClose();
              }}
              className="w-full flex items-center gap-4 px-4 py-3 rounded-lg hover:bg-gold/10 transition-colors text-left group"
            >
              <i className={`fa-solid ${item.icon} text-gold/80 group-hover:text-gold w-6 text-center`}></i>
              <span className="text-gray-200 group-hover:text-gold font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-10 left-0 w-full px-6">
          <p className="text-xs text-gray-500 text-center">
            &copy; {new Date().getFullYear()} Radio hamanieh-flash.net
            <br />Tous droits réservés.
          </p>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
