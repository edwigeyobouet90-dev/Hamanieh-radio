
import React, { useState, useRef, useEffect } from 'react';
import { STREAM_URL, RADIO_NAME } from '../constants';

interface AudioPlayerProps {
  onStatusChange: (status: 'playing' | 'paused' | 'loading') => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ onStatusChange }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const togglePlayback = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      // To properly "stop" a stream and save bandwidth, we clear the src
      audioRef.current.src = "";
      setIsPlaying(false);
      onStatusChange('paused');
    } else {
      setIsLoading(true);
      onStatusChange('loading');
      audioRef.current.src = STREAM_URL;
      audioRef.current.play()
        .then(() => {
          setIsPlaying(true);
          setIsLoading(false);
          onStatusChange('playing');
        })
        .catch(err => {
          console.error("Playback error:", err);
          setIsLoading(false);
          onStatusChange('paused');
        });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center gap-8 py-10">
      <audio ref={audioRef} preload="none" />
      
      {/* Visualizer Circle */}
      <div className={`relative w-64 h-64 rounded-full flex items-center justify-center ${isPlaying ? 'animate-pulse-gold' : ''}`}>
        <div className="absolute inset-0 rounded-full border-2 border-gold/20"></div>
        
        {/* Logo/Cover Area */}
        <div className="relative w-56 h-56 bg-gradient-to-br from-navy to-black rounded-full shadow-2xl overflow-hidden border-2 border-gold flex items-center justify-center group">
          <img 
            src="https://picsum.photos/seed/radio/400/400" 
            alt="Radio Brand" 
            className={`w-full h-full object-cover opacity-60 transition-transform duration-1000 ${isPlaying ? 'scale-110' : 'scale-100'}`}
          />
          <div className="absolute inset-0 bg-navy/40 flex items-center justify-center">
             <i className="fa-solid fa-microphone-lines text-gold text-5xl"></i>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-3xl font-bold text-gold mb-1 tracking-wider uppercase">{RADIO_NAME}</h2>
        <p className="text-gray-400 font-medium">Direct Radio Live</p>
      </div>

      {/* Main Controls */}
      <button 
        onClick={togglePlayback}
        disabled={isLoading}
        className={`w-24 h-24 rounded-full flex items-center justify-center bg-gold text-navy shadow-lg transition-all transform active:scale-95 ${isLoading ? 'opacity-80' : 'hover:scale-105'}`}
      >
        {isLoading ? (
          <i className="fa-solid fa-spinner fa-spin text-4xl"></i>
        ) : isPlaying ? (
          <i className="fa-solid fa-stop text-4xl ml-1"></i>
        ) : (
          <i className="fa-solid fa-play text-4xl ml-2"></i>
        )}
      </button>

      {/* Mini Visualizer (only visible when playing) */}
      <div className={`flex items-end gap-1 h-8 ${isPlaying ? 'opacity-100' : 'opacity-0'} transition-opacity`}>
        {[...Array(12)].map((_, i) => (
          <div 
            key={i} 
            className="visualizer-bar" 
            style={{ 
              height: isPlaying ? `${Math.random() * 100}%` : '4px',
              animation: isPlaying ? `bounce ${0.5 + Math.random()}s ease-in-out infinite alternate` : 'none'
            }}
          ></div>
        ))}
      </div>
      
      <style>{`
        @keyframes bounce {
          from { height: 10%; }
          to { height: 100%; }
        }
      `}</style>
    </div>
  );
};

export default AudioPlayer;
